import numpy as np
import pandas as pd
import os
import json
import ast

xlmr_dict = []
tulr_dict = []
dir = "SumEval/data/train"

# xlmr_language_codes = ['af', 'am', 'ar', 'as', 'az', 'be', 'bg', 'bn', 'br', 'bs', 'ca', 'cs', 'cy', 'da', 'de', 'el', 'en', 'es', 'et', 'eu', 'fa', 'fi', 'fr', 'fy', 'ga', 'gd', 'gl', 'gu', 'ha', 'he', 'hi', 'hu', 'hy', 'id', 'is', 'it', 'ja', 'jv', 'ka', 'kk', 'km', 'kn', 'ko', 'ku', 'ky', 'lo', 'lt', 'lv', 'mg', 'mk', 'ml', 'mr', 'ms', 'my', 'ne', 'nl', 'no', 'om', 'or', 'pa', 'pl', 'ps', 'pt', 'ro', 'ru', 'sd', 'si', 'sk', 'sl', 'so', 'sq', 'su', 'sv', 'sw', 'ta', 'te', 'th', 'tl', 'tr', 'ug', 'uk', 'ur', 'uz', 'vi', 'xh', 'yi', 'zh']
# tulrv6_language_codes = ["af", "am", "ar", "as", "az", "ba", "be", "bg", "bn", "ca", "ckb", "cs", "cy", "da", "de", "el", "en", "es", "et", "eu", "fa", "fi", "fr", "ga", "gl", "gu", "he", "hi", "hr", "hu", "hy", "id", "is", "it", "ja", "ka", "kk", "km", "kn", "ko", "ky", "la", "lo", "lt", "lv", "mk", "ml", "mr", "ms", "mt", "my", "ne", "nl", "nn", "no", "or", "pa", "pl", "ps", "pt", "ro", "ru", "sd", "si", "sk", "sl", "sq", "sr", "sv", "sw", "ta", "te", "tg", "th", "tl", "tr", "tt", "ug", "uk", "ur", "uz", "vi", "yi", "zh"]
# ALL_LANG_CODES = ['af', 'am', 'ar', 'as', 'az', 'ba', 'be', 'bg', 'bn', 'br', 'bs', 'ca','ckb', 'cs', 'cy', 'da', 'de', 'el', 'en', 'es', 'et', 'eu', 'fa', 'fi', 'fr', 'fy', 'ga', 'gd', 'gl', 'gu', 'ha', 'he', 'hi', 'hr', 'hu', 'hy', 'id', 'is', 'it', 'ja', 'jv', 'ka', 'kk', 'km', 'kn', 'ko', 'ku', 'ky', 'la', 'lo', 'lt', 'lv', 'mg', 'mk', 'ml', 'mr', 'ms', 'mt', 'my', 'ne', 'nl', 'nn', 'no', 'om', 'or', 'pa', 'pl', 'ps', 'pt', 'ro', 'ru', 'sd', 'si', 'sk', 'sl', 'so', 'sq', 'sr', 'su', 'sv', 'sw', 'ta', 'te', 'tg', 'th', 'tl', 'tr', 'tt', 'ug', 'uk', 'ur', 'uz', 'vi', 'xh', 'yi', 'zh']
#
# langs_iso = ['af', 'am', 'ar', 'as', 'az', 'ba', 'be', 'bg', 'bn', 'ca', 'ckb', 'cs', 'cy', 'da', 'de', 'el', 'en', 'es', 'et', 'eu', 'fa', 'fi', 'fr', 'ga', 'gl', 'gu', 'he', 'hi', 'hu', 'hy', 'id', 'is', 'it', 'ja', 'ka', 'kk', 'km', 'kn', 'ko', 'ky', 'lo', 'lt', 'lv', 'mk', 'ml', 'mr', 'ms', 'mt', 'my', 'ne', 'nl', 'no', 'or', 'pa', 'pl', 'ps', 'pt', 'ro', 'ru', 'sd', 'si', 'sk', 'sl', 'sq', 'sv', 'sw', 'ta', 'te', 'tg', 'th', 'tl', 'tr', 'tt', 'ug', 'uk', 'ur', 'uz', 'vi', 'yi', 'zh']
#
# for lang in ALL_LANG_CODES:
#     if lang not in langs_iso:
#         print(lang)

for filename in os.listdir(dir):
    if ".json" in filename:
        f = os.path.join(dir, filename)
        print(f)
        with open(f,'r') as data_file:
            data = json.loads(data_file.read())

        for i in range(len(data)):
            dict = {}
            dict = data[i]
            # print("************************************************************")
            # print(dict)
            # print(f)
            # print("************************************************************")

            if 'XLMR' in f:
                xlmr_dict.append(dict)
            else:
                tulr_dict.append(dict)

# filename = dir+"/processed/XLMR_minus_XNLI.json"
# with open(filename, "w") as outfile:
#     json.dump(xlmr_dict, outfile)
# #
# filename = dir+"/processed/TULRv6.json"
# with open(filename, "w") as outfile:
#     json.dump(tulr_dict, outfile)


# python3 SumEval/src/custom_train_file.py
